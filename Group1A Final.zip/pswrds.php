<?php
  $username1 = "z1853066";
  $password1 = "2000Apr16";
  $username2 = "student";
  $password2 = "student";
?>
