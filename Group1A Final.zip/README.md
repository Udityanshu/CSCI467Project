# CSCI467Project

Run database1 first and then database2 in MariaDB to create and populate the tables.


Links:

http://students.cs.niu.edu/~z1853066/CSCI467/Main/U/catalogpage.php

http://students.cs.niu.edu/~z1853066/CSCI467/Main/U/orders.php

http://students.cs.niu.edu/~z1853066/CSCI467/Main/U/receptiondesk.php

http://students.cs.niu.edu/~z1853066/CSCI467/Main/U/warehouse.php

http://students.cs.niu.edu/~z1853066/CSCI467/Main/U/invoiceview.php

http://students.cs.niu.edu/~z1853066/CSCI467/Main/U/weightcharge.php

